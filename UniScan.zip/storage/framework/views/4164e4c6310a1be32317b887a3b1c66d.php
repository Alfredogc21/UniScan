
<form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
    <?php echo csrf_field(); ?>
    <button type="submit" class="actions__button" title="Cerrar Sesión">
        <i class="fas fa-sign-out-alt"></i>
    </button>
</form>
<?php /**PATH C:\xampp\htdocs\Proyecto\UniScan\resources\views/partials/logout_button.blade.php ENDPATH**/ ?>